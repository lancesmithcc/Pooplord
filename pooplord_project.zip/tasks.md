# Tasks

- [x] Fix TypeScript error in `PooplordGame.tsx`: Property 'x' does not exist on type 'CharacterState'. 